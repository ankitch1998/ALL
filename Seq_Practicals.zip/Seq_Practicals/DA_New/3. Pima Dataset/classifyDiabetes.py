from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score
import pandas as pd
import numpy as np
df = pd.read_csv("diabetes.csv")
x = df[['Pregnancies','Glucose','BloodPressure','SkinThickness','Insulin','BMI','DiabetesPedigreeFunction','Age']]
y = df[['Outcome']]
train_x,test_x,train_y,test_y =  train_test_split(x,y, test_size=0.3)
print (train_x.shape)
print (test_x.shape)
desc =  train_x.describe()
print (desc)
classifier = GaussianNB()
classifier.fit(train_x,np.array(train_y).ravel() )  
predicted_test_y = classifier.predict(test_x)
print (predicted_test_y)
