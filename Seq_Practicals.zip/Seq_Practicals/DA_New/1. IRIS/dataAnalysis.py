import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv("iris.csv")
print(df.head())
print (df.tail())
cols = df.columns
print (df.info())
df2 = df[['sepal_length','petal_width']]
print (df2.head())
print (df['class'].unique().shape)
print (df['sepal_length'].unique().shape)
print (df.mean(axis=1))
print (df.max(axis=0))
print (df.min(axis=0))
print (df.std(axis=0))
for col in cols[:-1]:
	(df.hist([col]))
df.boxplot(by ='class', column =['sepal_length','petal_width'], grid = False) 
plt.show()